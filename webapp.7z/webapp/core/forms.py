# -*- coding: utf-8 -*-
"""
Created on 6/16/2017 4:19 PM 2017

@author: cleavitt
"""

from django import forms
from django.contrib.auth.forms import UserCreationForm

from .models import User
# from django.conf import settings


class SignUpForm(UserCreationForm):
    email = forms.EmailField(
        max_length=254, help_text='Required', required=True)
    first_name = forms.CharField(
        max_length=30, help_text='Required', required=True)
    last_name = forms.CharField(
        max_length=30, help_text='Required', required=True)

    class Meta:
        # model = settings.AUTH_USER_MODEL
        model = User
        fields = ('username', 'first_name', 'last_name', 'email', 'password1',
                  'password2',)
