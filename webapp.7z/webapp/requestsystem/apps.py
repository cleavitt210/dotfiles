from django.apps import AppConfig


class RequestsystemConfig(AppConfig):
    name = 'requestsystem'
