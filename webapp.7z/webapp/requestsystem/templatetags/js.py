# -*- coding: utf-8 -*-
"""
Created on 8/15/2017 9:13 AM 2017

@author: cleavitt
"""

import json

from django.template import Library
from django.utils.safestring import mark_safe

register = Library()


@register.filter(is_safe=True)
def js(obj):
    return mark_safe(json.dumps(obj))
