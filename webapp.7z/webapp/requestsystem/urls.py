# -*- coding: utf-8 -*-
"""
Created on 8/15/2017 4:02 PM 2017

@author: cleavitt
"""

# -*- coding: utf-8 -*-
"""
Created on 6/13/2017 1:04 PM 2017

@author: cleavitt
"""

from django.conf.urls import url

from . import views

urlpatterns = [
    # url(r'^$', views.index, name='workorder_home'),
]
