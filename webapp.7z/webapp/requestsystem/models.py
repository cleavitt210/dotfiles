from __future__ import unicode_literals

from django.db import models


class BallMillingLot(models.Model):
    lot_id = models.OneToOneField(
        'Lot', models.CASCADE, db_column='LotID', primary_key=True)
    media_lot_id = models.ForeignKey(
        'Lot', models.CASCADE, db_column='MediaLotID',
        related_name='media_lot_used'
    )
    shelf = models.CharField(db_column='Shelf', max_length=50)
    location = models.CharField(db_column='Location', max_length=50)
    rpm = models.DecimalField(db_column='RPM', max_digits=18, decimal_places=6)
    weight = models.DecimalField(
        db_column='Weight', max_digits=18, decimal_places=6)

    class Meta:
        db_table = 'BallMillingLot'


class BallMillingProcessComponent(models.Model):
    component_id = models.OneToOneField(
        'Component', models.CASCADE, db_column='ComponentID', primary_key=True)
    media_part_id = models.ForeignKey(
        'Part', models.CASCADE, db_column='MediaPartID',
        related_name='media_part_required'
    )
    weight = models.DecimalField(
        db_column='Weight', max_digits=18, decimal_places=6)
    rpm = models.DecimalField(db_column='RPM', max_digits=18, decimal_places=6)

    class Meta:
        db_table = 'BallMillingProcessComponent'


class CellProcessComponent(models.Model):
    component_id = models.OneToOneField(
        'Component', models.CASCADE, db_column='ComponentID', primary_key=True)
    machine_id = models.ForeignKey(
        'Machine', models.CASCADE, db_column='MachineID')

    class Meta:
        db_table = 'CellProcessComponent'


class Component(models.Model):
    component_id = models.AutoField(db_column='ComponentID', primary_key=True)

    class Meta:
        db_table = 'Component'


class Document(models.Model):
    document_id = models.AutoField(db_column='DocumentID', primary_key=True)
    bin = models.BinaryField(db_column='Bin')

    class Meta:
        db_table = 'Document'


class DryingLot(models.Model):
    lot_id = models.OneToOneField(
        'Lot', models.CASCADE, db_column='LotID', primary_key=True)
    oven = models.CharField(db_column='Oven', max_length=50)
    program = models.IntegerField(db_column='Program')
    temp = models.IntegerField(db_column='Temp')
    timeattemp = models.IntegerField(db_column='TimeAtTemp')
    timetotal = models.IntegerField(db_column='TimeTotal')

    class Meta:
        db_table = 'DryingLot'


class DryingProcessComponent(models.Model):
    component_id = models.OneToOneField(
        Component, models.CASCADE, db_column='ComponentID', primary_key=True)
    oven = models.CharField(db_column='Oven', max_length=50)
    program = models.IntegerField(db_column='Program')
    temp = models.DecimalField(
        db_column='Temp', max_digits=18, decimal_places=6)
    time_at_temp = models.IntegerField(db_column='TimeAtTemp')
    time_total = models.IntegerField(db_column='TimeTotal')

    class Meta:
        db_table = 'DryingProcessComponent'


class ElectrolyteProcessComponent(models.Model):
    component_id = models.OneToOneField(
        Component, models.CASCADE, db_column='ComponentID', primary_key=True)
    mixing_equipment = models.CharField(
        db_column='MixingEquipment', max_length=50)
    mixing_location = models.CharField(
        db_column='MixingLocation', max_length=100)
    mixing_time = models.IntegerField(db_column='MixingTime')
    mixing_speed = models.DecimalField(
        db_column='MixingSpeed', max_digits=18, decimal_places=6)
    container_size = models.IntegerField(db_column='ContainerSize')

    class Meta:
        db_table = 'ElectrolyteProcessComponent'


class Lot(models.Model):
    lot_id = models.AutoField(db_column='LotID', primary_key=True)
    lot_code = models.CharField(
        db_column='LotCode', unique=True, max_length=11)
    quantity = models.DecimalField(
        db_column='Quantity', max_digits=18, decimal_places=6)
    units = models.CharField(
        db_column='Units', max_length=50, blank=True, null=True)
    notes = models.CharField(
        db_column='Notes', max_length=4000, blank=True, null=True)

    class Meta:
        db_table = 'Lot'


class LotBOM(models.Model):
    lot_item_id = models.AutoField(db_column='LotItemID', primary_key=True)
    parent_lot_id = models.ForeignKey(
        Lot, models.CASCADE, db_column='ParentLotID', related_name='parent_lot'
    )
    child_lot_id = models.ForeignKey(
        Lot, models.CASCADE, db_column='ChildLotID', related_name='child_lot')
    child_quantity = models.DecimalField(
        db_column='ChildQuantity', max_digits=18, decimal_places=6)
    child_units = models.CharField(
        db_column='ChildUnits', max_length=50, blank=True, null=True)

    class Meta:
        db_table = 'LotBOM'


class Machine(models.Model):
    machine_id = models.IntegerField(db_column='MachineID', primary_key=True)
    machine_name = models.CharField(db_column='MachineName', max_length=80)
    machine_name_short = models.CharField(
        db_column='MachineNameShort', max_length=20)
    machine_sn = models.CharField(db_column='MachineSN', max_length=50)
    part_name = models.CharField(db_column='PartName', max_length=20)

    class Meta:
        db_table = 'Machine'


class NipponCokeMillingLot(models.Model):
    lot_id = models.OneToOneField(
        Lot, models.CASCADE, db_column='LotID', primary_key=True)
    main_blade_speed = models.DecimalField(
        db_column='MainBladeSpeed', max_digits=18, decimal_places=6,
        blank=True, null=True
    )
    cross_screw_speed = models.DecimalField(
        db_column='CrossScrewSpeed', max_digits=18, decimal_places=6,
        blank=True, null=True
    )
    cooling_flow_speed = models.DecimalField(
        db_column='CoolingFlowSpeed', max_digits=18, decimal_places=6,
        blank=True, null=True
    )
    cooling_temp = models.DecimalField(
        db_column='CoolingTemp', max_digits=18, decimal_places=6, blank=True,
        null=True
    )

    class Meta:
        db_table = 'NipponCokeMillingLot'


class NipponCokeMillingProcessComponent(models.Model):
    component_id = models.OneToOneField(
        Component, models.CASCADE, db_column='ComponentID', primary_key=True)
    main_blade_speed = models.DecimalField(
        db_column='MainBladeSpeed', max_digits=18, decimal_places=6,
        blank=True, null=True
    )
    cross_screw_speed = models.DecimalField(
        db_column='CrossScrewSpeed', max_digits=18, decimal_places=6,
        blank=True, null=True
    )
    cooling_flow_speed = models.DecimalField(
        db_column='CoolingFlowSpeed', max_digits=18, decimal_places=6,
        blank=True, null=True
    )
    cooling_temp = models.DecimalField(
        db_column='CoolingTemp', max_digits=18, decimal_places=6, blank=True,
        null=True
    )

    class Meta:
        db_table = 'NipponCokeMillingProcessComponent'


class Request(models.Model):
    request_id = models.AutoField(db_column='RequestID', primary_key=True)
    descriptor = models.CharField(
        db_column='Descriptor', unique=True, max_length=8)
    request_type = models.CharField(db_column='RequestType', max_length=25)
    requested_dts = models.DateTimeField(db_column='RequestedDTS')
    requested_by = models.CharField(db_column='RequestedBy', max_length=100)
    purpose = models.CharField(db_column='Purpose', max_length=4000)
    notes = models.CharField(
        db_column='Notes', max_length=4000, blank=True, null=True)
    program = models.CharField(db_column='Program', max_length=500)
    approved = models.BooleanField(db_column='Approved', default=0)
    lot = models.ManyToManyField(Lot)

    class Meta:
        db_table = 'Request'


class Supplier(models.Model):
    supplier_id = models.AutoField(db_column='SupplierID', primary_key=True)
    supplier_name = models.CharField(
        db_column='SupplierName', max_length=100, unique=True)

    class Meta:
        db_table = 'Supplier'


class Part(models.Model):
    part_id = models.AutoField(db_column='PartID', primary_key=True)
    part_number = models.CharField(
        db_column='PartNumber', max_length=36, unique=True)
    part_name = models.CharField(db_column='PartName', max_length=100)
    category = models.CharField(db_column='Category', max_length=50)
    description = models.CharField(
        db_column='Description', max_length=500, blank=True, null=True)
    request = models.ManyToManyField(Request)
    supplier = models.ManyToManyField(Supplier, through='SupplierPart')

    class Meta:
        db_table = 'Part'


class PartBOM(models.Model):
    part_bom_id = models.AutoField(
        db_column='PartBOMID', primary_key=True)
    parent_part_id = models.ForeignKey(
        Part, models.CASCADE, db_column='ParentPartID',
        related_name='parent_part'
    )
    child_part_id = models.ForeignKey(
        Part, models.CASCADE, db_column='ChildPartID',
        related_name='child_part'
    )
    child_value = models.DecimalField(
        db_column='ChildQuantity', max_digits=18, decimal_places=6)
    child_units = models.CharField(
        db_column='ChildUnits', max_length=50, blank=True, null=True)

    class Meta:
        db_table = 'PartBOM'


class PowderLot(models.Model):
    lot_id = models.OneToOneField(
        Lot, models.CASCADE, db_column='LotID', primary_key=True)
    container_size = models.IntegerField(
        db_column='ContainerSize', blank=True, null=True)
    milling_equipment = models.CharField(
        db_column='MillingEquipment', max_length=50, blank=True, null=True)
    milling_time = models.IntegerField(
        db_column='MillingTime', blank=True, null=True)
    milling_jar_speed = models.IntegerField(
        db_column='MillingJarSpeed', blank=True, null=True)
    milling_location = models.CharField(
        db_column='MillingLocation', max_length=100, blank=True, null=True)

    class Meta:
        db_table = 'PowderLot'


class PowderProcessComponent(models.Model):
    component_id = models.OneToOneField(
        Component, models.CASCADE, db_column='ComponentID', primary_key=True)
    container_size = models.IntegerField(
        db_column='ContainerSize', blank=True, null=True)
    milling_equipment = models.CharField(
        db_column='MillingEquipment', max_length=50, blank=True, null=True)
    milling_time = models.IntegerField(
        db_column='MillingTime', blank=True, null=True)
    milling_jar_speed = models.DecimalField(
        db_column='MillingJarSpeed', max_digits=18, decimal_places=6,
        blank=True, null=True
    )
    milling_location = models.CharField(
        db_column='MillingLocation', max_length=100, blank=True, null=True)

    class Meta:
        db_table = 'PowderProcessComponent'


class PowrexMillingLot(models.Model):
    lot_id = models.OneToOneField(
        Lot, models.CASCADE, db_column='LotID', primary_key=True)

    class Meta:
        db_table = 'PowrexMillingLot'


class PowrexMillingProcessComponent(models.Model):
    component_id = models.OneToOneField(
        Component, models.CASCADE, db_column='ComponentID', primary_key=True)

    class Meta:
        db_table = 'PowrexMillingProcessComponent'


class Process(models.Model):
    process_id = models.AutoField(db_column='ProcessID', primary_key=True)
    description = models.CharField(
        db_column='Description', max_length=4000, blank=True, null=True)
    process_type = models.CharField(
        db_column='ProcessType', max_length=25, blank=True, null=True)
    process_name = models.CharField(
        db_column='ProcessName', max_length=50, blank=True, null=True)
    request = models.ManyToManyField(Request)
    component = models.ManyToManyField(Component)

    class Meta:
        db_table = 'Process'


class ReceivedMaterialLot(models.Model):
    lot_id = models.OneToOneField(
        Lot, models.CASCADE, db_column='LotID', primary_key=True)
    supplier_lot_code = models.CharField(
        db_column='SupplierLotCode', max_length=50, blank=True, null=True)
    received_by = models.CharField(db_column='ReceivedBy', max_length=100)
    received_dts = models.DateTimeField(db_column='ReceivedDTS')
    purchase_order_number = models.IntegerField(
        db_column='PurchaseOrderNumber', blank=True, null=True)
    expiration_date = models.DateTimeField(
        db_column='ExpirationDate', blank=True, null=True)
    document_id = models.ForeignKey(
        Document, models.CASCADE, db_column='DocumentID', blank=True, null=True
    )
    supplier_id = models.ForeignKey(
        Supplier, models.CASCADE, db_column='SupplierID')

    class Meta:
        db_table = 'ReceivedMaterialLot'


class SlurryProcessComponent(models.Model):
    component_id = models.OneToOneField(
        Component, models.CASCADE, db_column='ComponentID', primary_key=True)
    mixing_instructions = models.CharField(
        db_column='MixingInstructions', max_length=4000)
    order_of_addition = models.CharField(
        db_column='OrderOfAddition', max_length=4000)

    class Meta:
        db_table = 'SlurryProcessComponent'


class SupplierPart(models.Model):
    supplier_id = models.ForeignKey(
        Supplier, models.CASCADE, db_column='SupplierID')
    part_id = models.ForeignKey(
        Part, models.CASCADE, db_column='PartID')
    supplier_part_number = models.CharField(
        db_column='SupplierPartNumber', max_length=100, blank=True,
        null=True)

    class Meta:
        db_table = 'Supplier_Part'
        unique_together = (('supplier_id', 'part_id', 'supplier_part_number'),)
